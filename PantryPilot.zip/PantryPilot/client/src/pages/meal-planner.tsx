import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar, Plus, Trash2, Clock, Users, ChefHat } from "lucide-react";
import { format, startOfWeek, addDays, isSameDay } from "date-fns";
import type { Recipe, MealPlan } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import emptyMealsImage from "@assets/generated_images/no_meals_planned_illustration.png";

const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const mealTypes = ["Breakfast", "Lunch", "Dinner", "Snack"];

export default function MealPlanner() {
  const [currentWeekStart, setCurrentWeekStart] = useState(
    startOfWeek(new Date(), { weekStartsOn: 1 })
  );
  const [addMealOpen, setAddMealOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedMealType, setSelectedMealType] = useState("");
  const [selectedRecipeId, setSelectedRecipeId] = useState("");
  const { toast } = useToast();

  const { data: recipes = [] } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const { data: mealPlans = [], isLoading } = useQuery<MealPlan[]>({
    queryKey: ["/api/meal-plans"],
  });

  const addMealMutation = useMutation({
    mutationFn: () => {
      if (!selectedDate || !selectedMealType || !selectedRecipeId) {
        return Promise.reject(new Error("Missing required fields"));
      }
      return apiRequest("POST", "/api/meal-plans", {
        recipeId: selectedRecipeId,
        date: selectedDate.toISOString(),
        mealType: selectedMealType.toLowerCase(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      toast({
        title: "Meal added",
        description: "Your meal has been scheduled successfully.",
      });
      setAddMealOpen(false);
      setSelectedDate(null);
      setSelectedMealType("");
      setSelectedRecipeId("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add meal. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMealMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/meal-plans/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      toast({
        title: "Meal removed",
        description: "The meal has been removed from your plan.",
      });
    },
  });

  const getMealsForDateAndType = (date: Date, mealType: string) => {
    return mealPlans.filter(
      (plan) => {
        try {
          return isSameDay(new Date(plan.date), date) &&
            plan.mealType.toLowerCase() === mealType.toLowerCase();
        } catch {
          return false;
        }
      }
    );
  };

  const openAddMealDialog = (date: Date, mealType: string) => {
    setSelectedDate(date);
    setSelectedMealType(mealType);
    setAddMealOpen(true);
  };

  const goToPreviousWeek = () => {
    setCurrentWeekStart(addDays(currentWeekStart, -7));
  };

  const goToNextWeek = () => {
    setCurrentWeekStart(addDays(currentWeekStart, 7));
  };

  const goToCurrentWeek = () => {
    setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }));
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-1/3 mb-8" />
          <div className="h-96 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">Meal Planner</h1>
            <p className="text-muted-foreground">Plan your meals for the week</p>
          </div>
          <Button asChild data-testid="button-browse-recipes">
            <Link href="/recipes">
              <ChefHat className="h-4 w-4 mr-2" />
              Browse Recipes
            </Link>
          </Button>
        </div>

        {/* Week Navigator */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={goToPreviousWeek} data-testid="button-previous-week">
              Previous
            </Button>
            <Button variant="outline" onClick={goToCurrentWeek} data-testid="button-current-week">
              This Week
            </Button>
            <Button variant="outline" onClick={goToNextWeek} data-testid="button-next-week">
              Next
            </Button>
          </div>
          <div className="text-lg font-semibold" data-testid="text-week-range">
            {format(currentWeekStart, "MMM d")} - {format(addDays(currentWeekStart, 6), "MMM d, yyyy")}
          </div>
        </div>

        {/* Calendar Grid */}
        <div className="overflow-x-auto">
          <div className="min-w-[900px]">
            {/* Header Row */}
            <div className="grid grid-cols-8 gap-2 mb-2">
              <div className="font-medium text-sm text-muted-foreground"></div>
              {daysOfWeek.map((day, index) => {
                const date = addDays(currentWeekStart, index);
                const isToday = isSameDay(date, new Date());
                return (
                  <div
                    key={day}
                    className={`text-center font-semibold p-2 rounded-md ${
                      isToday ? "bg-primary text-primary-foreground" : ""
                    }`}
                    data-testid={`header-day-${index}`}
                  >
                    <div className="text-sm">{day}</div>
                    <div className="text-xs opacity-80">{format(date, "MMM d")}</div>
                  </div>
                );
              })}
            </div>

            {/* Meal Rows */}
            {mealTypes.map((mealType) => (
              <div key={mealType} className="grid grid-cols-8 gap-2 mb-2">
                <div className="flex items-center justify-center font-medium text-sm p-2 bg-muted rounded-md">
                  {mealType}
                </div>
                {daysOfWeek.map((day, dayIndex) => {
                  const date = addDays(currentWeekStart, dayIndex);
                  const meals = getMealsForDateAndType(date, mealType);

                  return (
                    <div
                      key={`${day}-${mealType}`}
                      className="min-h-24 p-2 border-2 border-dashed border-border rounded-md hover-elevate"
                      data-testid={`cell-${mealType.toLowerCase()}-${dayIndex}`}
                    >
                      {meals.length > 0 ? (
                        <div className="space-y-2">
                          {meals.map((meal) => {
                            const recipe = recipes.find((r) => r.id === meal.recipeId);
                            if (!recipe) return null;

                            return (
                              <Card
                                key={meal.id}
                                className="cursor-pointer group relative overflow-hidden"
                                data-testid={`meal-card-${meal.id}`}
                              >
                                <CardContent className="p-2">
                                  <div className="flex gap-2">
                                    {recipe.imageUrl && (
                                      <img
                                        src={recipe.imageUrl}
                                        alt={recipe.name}
                                        className="h-12 w-12 rounded object-cover flex-shrink-0"
                                      />
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <p className="text-xs font-semibold truncate">{recipe.name}</p>
                                      <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                                        <Clock className="h-3 w-3" />
                                        <span>{recipe.prepTime + recipe.cookTime}m</span>
                                        <Users className="h-3 w-3 ml-1" />
                                        <span>{recipe.servings}</span>
                                      </div>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => deleteMealMutation.mutate(meal.id)}
                                    data-testid={`button-delete-meal-${meal.id}`}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </CardContent>
                              </Card>
                            );
                          })}
                        </div>
                      ) : (
                        <button
                          onClick={() => openAddMealDialog(date, mealType)}
                          className="w-full h-full flex flex-col items-center justify-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
                          data-testid={`button-add-meal-${mealType.toLowerCase()}-${dayIndex}`}
                        >
                          <Plus className="h-4 w-4" />
                          <span className="text-xs">Add meal</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Add Meal Dialog */}
      <Dialog open={addMealOpen} onOpenChange={setAddMealOpen}>
        <DialogContent data-testid="dialog-add-meal">
          <DialogHeader>
            <DialogTitle>Add Meal</DialogTitle>
            <DialogDescription>
              {selectedDate && selectedMealType && (
                <>
                  Choose a recipe for {selectedMealType.toLowerCase()} on{" "}
                  {format(selectedDate, "EEEE, MMMM d")}
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Select value={selectedRecipeId} onValueChange={setSelectedRecipeId}>
              <SelectTrigger data-testid="select-recipe">
                <SelectValue placeholder="Select a recipe" />
              </SelectTrigger>
              <SelectContent>
                {recipes.length > 0 ? (
                  recipes.map((recipe) => (
                    <SelectItem key={recipe.id} value={recipe.id}>
                      {recipe.name} ({recipe.category})
                    </SelectItem>
                  ))
                ) : (
                  <div className="p-4 text-center text-sm text-muted-foreground">
                    No recipes available
                  </div>
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => addMealMutation.mutate()}
              disabled={!selectedRecipeId || addMealMutation.isPending}
              data-testid="button-confirm-add-meal"
            >
              {addMealMutation.isPending ? "Adding..." : "Add Meal"}
            </Button>
            {recipes.length === 0 && (
              <Button variant="outline" asChild data-testid="button-create-recipe">
                <Link href="/recipes/new">Create Recipe</Link>
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
