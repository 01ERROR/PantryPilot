import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Package, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import type { PantryItem } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import emptyPantryImage from "@assets/generated_images/empty_pantry_illustration.png";

const categories = ["Produce", "Dairy", "Meat", "Grains", "Canned", "Frozen", "Spices", "Other"];
const units = ["cups", "tbsp", "tsp", "lbs", "oz", "items", "grams", "ml", "liters"];

export default function Pantry() {
  const [addItemOpen, setAddItemOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    quantity: 1,
    unit: "items",
    category: "Other",
    purchaseDate: new Date().toISOString().split("T")[0],
    expirationDate: "",
  });
  const { toast } = useToast();

  const { data: pantryItems = [], isLoading } = useQuery<PantryItem[]>({
    queryKey: ["/api/pantry"],
  });

  const addItemMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/pantry", {
        ...formData,
        purchaseDate: new Date(formData.purchaseDate).toISOString(),
        expirationDate: formData.expirationDate
          ? new Date(formData.expirationDate).toISOString()
          : null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pantry"] });
      toast({
        title: "Item added",
        description: "The item has been added to your pantry.",
      });
      setAddItemOpen(false);
      setFormData({
        name: "",
        quantity: 1,
        unit: "items",
        category: "Other",
        purchaseDate: new Date().toISOString().split("T")[0],
        expirationDate: "",
      });
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/pantry/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pantry"] });
      toast({
        title: "Item removed",
        description: "The item has been removed from your pantry.",
      });
    },
  });

  const expiringItems = pantryItems.filter((item) => {
    if (!item.expirationDate) return false;
    try {
      const expDate = new Date(item.expirationDate);
      const today = new Date();
      const daysUntilExpiry = Math.floor((expDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return daysUntilExpiry >= 0 && daysUntilExpiry <= 7;
    } catch {
      return false;
    }
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-1/3 mb-8" />
          <div className="h-96 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Pantry Inventory</h1>
            <p className="text-muted-foreground">Track your ingredients and expiration dates</p>
          </div>
          <Dialog open={addItemOpen} onOpenChange={setAddItemOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-item">
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent data-testid="dialog-add-item">
              <DialogHeader>
                <DialogTitle>Add Pantry Item</DialogTitle>
                <DialogDescription>Add a new item to your pantry inventory.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="item-name">Item Name</Label>
                  <Input
                    id="item-name"
                    placeholder="e.g., All-purpose flour"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    data-testid="input-item-name"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                      data-testid="input-quantity"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Unit</Label>
                    <Select
                      value={formData.unit}
                      onValueChange={(value) => setFormData({ ...formData, unit: value })}
                    >
                      <SelectTrigger id="unit" data-testid="select-unit">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {units.map((unit) => (
                          <SelectItem key={unit} value={unit}>
                            {unit}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger id="category" data-testid="select-category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="purchase-date">Purchase Date</Label>
                    <Input
                      id="purchase-date"
                      type="date"
                      value={formData.purchaseDate}
                      onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
                      data-testid="input-purchase-date"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expiration-date">Expiration Date (Optional)</Label>
                    <Input
                      id="expiration-date"
                      type="date"
                      value={formData.expirationDate}
                      onChange={(e) => setFormData({ ...formData, expirationDate: e.target.value })}
                      data-testid="input-expiration-date"
                    />
                  </div>
                </div>
              </div>
              <Button
                onClick={() => addItemMutation.mutate()}
                disabled={!formData.name || addItemMutation.isPending}
                data-testid="button-confirm-add-item"
              >
                {addItemMutation.isPending ? "Adding..." : "Add Item"}
              </Button>
            </DialogContent>
          </Dialog>
        </div>

        {/* Expiring Soon Alert */}
        {expiringItems.length > 0 && (
          <Card className="mb-6 border-destructive" data-testid="card-expiring-alert">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
                <CardTitle className="text-base">Items Expiring Soon</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                {expiringItems.length} item{expiringItems.length !== 1 ? "s" : ""} expiring within 7 days
              </p>
              <div className="flex flex-wrap gap-2">
                {expiringItems.map((item) => (
                  <Badge key={item.id} variant="destructive" data-testid={`badge-expiring-${item.id}`}>
                    {item.name} - {item.expirationDate && format(new Date(item.expirationDate), "MMM d")}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pantry Table */}
        {pantryItems.length > 0 ? (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item Name</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Purchase Date</TableHead>
                  <TableHead>Expiration Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pantryItems.map((item) => (
                  <TableRow key={item.id} data-testid={`row-pantry-item-${item.id}`}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>
                      {item.quantity} {item.unit}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.category}</Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {format(new Date(item.purchaseDate), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {item.expirationDate ? format(new Date(item.expirationDate), "MMM d, yyyy") : "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteItemMutation.mutate(item.id)}
                        data-testid={`button-delete-${item.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <img src={emptyPantryImage} alt="Empty pantry" className="h-32 w-32 mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">Your pantry is empty</h3>
            <p className="text-muted-foreground mb-6">Start tracking your ingredients to reduce food waste</p>
            <Button onClick={() => setAddItemOpen(true)} data-testid="button-add-first-item">
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Item
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
