import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Clock, Users, Plus, ChefHat } from "lucide-react";
import { Link } from "wouter";
import type { Recipe } from "@shared/schema";
import emptyRecipesImage from "@assets/generated_images/no_meals_planned_illustration.png";

const categories = ["All", "Breakfast", "Lunch", "Dinner", "Snacks"];
const difficulties = ["All", "Easy", "Medium", "Hard"];

export default function Recipes() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedDifficulty, setSelectedDifficulty] = useState("All");

  const { data: recipes = [], isLoading } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipe.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || recipe.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesDifficulty = selectedDifficulty === "All" || recipe.difficulty.toLowerCase() === selectedDifficulty.toLowerCase();
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="animate-pulse">
              <div className="aspect-video bg-muted" />
              <CardContent className="p-4">
                <div className="h-6 bg-muted rounded mb-2" />
                <div className="h-4 bg-muted rounded w-3/4" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b bg-background sticky top-0 z-10">
        <div className="p-8 pb-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">Recipe Library</h1>
              <p className="text-muted-foreground">Discover delicious meals and save your favorites</p>
            </div>
            <Button asChild data-testid="button-add-recipe">
              <Link href="/recipes/new">
                <Plus className="h-4 w-4 mr-2" />
                Add Recipe
              </Link>
            </Button>
          </div>

          {/* Search Bar */}
          <div className="relative max-w-2xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search recipes..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search-recipes"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="px-8 pb-4 flex flex-wrap gap-2">
          <div className="flex gap-2">
            {categories.map(category => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                className="cursor-pointer hover-elevate"
                onClick={() => setSelectedCategory(category)}
                data-testid={`filter-category-${category.toLowerCase()}`}
              >
                {category}
              </Badge>
            ))}
          </div>
          <div className="h-6 w-px bg-border" />
          <div className="flex gap-2">
            {difficulties.map(difficulty => (
              <Badge
                key={difficulty}
                variant={selectedDifficulty === difficulty ? "default" : "outline"}
                className="cursor-pointer hover-elevate"
                onClick={() => setSelectedDifficulty(difficulty)}
                data-testid={`filter-difficulty-${difficulty.toLowerCase()}`}
              >
                {difficulty}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      {/* Recipe Grid */}
      <div className="flex-1 overflow-auto p-8">
        {filteredRecipes.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredRecipes.map(recipe => (
              <Link key={recipe.id} href={`/recipes/${recipe.id}`}>
                <Card className="overflow-hidden hover-elevate cursor-pointer transition-transform group" data-testid={`card-recipe-${recipe.id}`}>
                  <div className="aspect-video relative overflow-hidden">
                    {recipe.imageUrl ? (
                      <img
                        src={recipe.imageUrl}
                        alt={recipe.name}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-200"
                      />
                    ) : (
                      <div className="h-full w-full bg-muted flex items-center justify-center">
                        <ChefHat className="h-12 w-12 text-muted-foreground" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                    <Badge className="absolute top-3 right-3" data-testid={`badge-category-${recipe.id}`}>
                      {recipe.category}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2 line-clamp-1" data-testid={`text-recipe-name-${recipe.id}`}>
                      {recipe.name}
                    </h3>
                    {recipe.description && (
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {recipe.description}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{recipe.prepTime + recipe.cookTime} min</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        <span>{recipe.servings}</span>
                      </div>
                      <Badge variant="secondary" className="ml-auto" data-testid={`badge-difficulty-${recipe.id}`}>
                        {recipe.difficulty}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <img src={emptyRecipesImage} alt="No recipes found" className="h-32 w-32 mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No recipes found</h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery || selectedCategory !== "All" || selectedDifficulty !== "All"
                ? "Try adjusting your filters or search query"
                : "Get started by adding your first recipe"}
            </p>
            {!searchQuery && selectedCategory === "All" && selectedDifficulty === "All" && (
              <Button asChild data-testid="button-add-first-recipe">
                <Link href="/recipes/new">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Recipe
                </Link>
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
