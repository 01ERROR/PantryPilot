import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Book, Package, ShoppingCart, Clock, Users } from "lucide-react";
import { Link } from "wouter";
import type { Recipe, MealPlan, PantryItem } from "@shared/schema";
import { format, addDays, startOfWeek, isSameDay } from "date-fns";
import heroImage from "@assets/generated_images/kitchen_pantry_hero_image.png";

export default function Dashboard() {
  const { data: recipes = [] } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const { data: mealPlans = [] } = useQuery<MealPlan[]>({
    queryKey: ["/api/meal-plans"],
  });

  const { data: pantryItems = [] } = useQuery<PantryItem[]>({
    queryKey: ["/api/pantry"],
  });

  const { data: shoppingList = [] } = useQuery<any[]>({
    queryKey: ["/api/shopping-list"],
  });

  // Calculate stats
  const today = new Date();
  const weekStart = startOfWeek(today, { weekStartsOn: 1 });
  const thisWeekMealPlans = mealPlans.filter(plan => {
    const planDate = new Date(plan.date);
    return planDate >= weekStart && planDate <= addDays(weekStart, 6);
  });

  const expiringItems = pantryItems.filter(item => {
    if (!item.expirationDate) return false;
    try {
      const expDate = new Date(item.expirationDate);
      const daysUntilExpiry = Math.floor((expDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return daysUntilExpiry >= 0 && daysUntilExpiry <= 7;
    } catch {
      return false;
    }
  });

  const incompleteShoppingItems = shoppingList.filter(item => !item.checked);

  // Get upcoming meals for the next 7 days
  const upcomingMeals = mealPlans
    .filter(plan => {
      try {
        return new Date(plan.date) >= today;
      } catch {
        return false;
      }
    })
    .sort((a, b) => {
      try {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      } catch {
        return 0;
      }
    })
    .slice(0, 7);

  const quickActions = [
    {
      title: "Plan This Week",
      description: "Schedule your meals for the week",
      icon: Calendar,
      href: "/meal-planner",
      testId: "card-plan-week",
    },
    {
      title: "Browse Recipes",
      description: "Explore delicious meal ideas",
      icon: Book,
      href: "/recipes",
      testId: "card-browse-recipes",
    },
    {
      title: "Check Pantry",
      description: "View and manage your ingredients",
      icon: Package,
      href: "/pantry",
      testId: "card-check-pantry",
    },
    {
      title: "Shopping List",
      description: "See what you need to buy",
      icon: ShoppingCart,
      href: "/shopping-list",
      testId: "card-shopping-list",
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <div className="relative h-64 overflow-hidden">
        <img
          src={heroImage}
          alt="Organized kitchen pantry"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
        <div className="absolute inset-0 flex flex-col justify-center px-8 text-white">
          <h1 className="text-4xl font-bold mb-2" data-testid="text-welcome">Welcome to PantryPilot</h1>
          <p className="text-lg text-white/90">Your smart kitchen companion for meal planning and grocery management</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-8">
        {/* Stats Overview */}
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          <Card data-testid="card-stat-meals">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Meals Planned</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-meals-count">{thisWeekMealPlans.length}</div>
              <p className="text-xs text-muted-foreground">This week</p>
            </CardContent>
          </Card>

          <Card data-testid="card-stat-expiring">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-expiring-count">{expiringItems.length}</div>
              <p className="text-xs text-muted-foreground">Within 7 days</p>
            </CardContent>
          </Card>

          <Card data-testid="card-stat-shopping">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Shopping Items</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-shopping-count">{incompleteShoppingItems.length}</div>
              <p className="text-xs text-muted-foreground">Items to buy</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {quickActions.map((action) => (
              <Link key={action.title} href={action.href}>
                <Card className="hover-elevate cursor-pointer transition-transform" data-testid={action.testId}>
                  <CardContent className="p-6">
                    <action.icon className="h-8 w-8 text-primary mb-3" />
                    <h3 className="font-semibold mb-1">{action.title}</h3>
                    <p className="text-sm text-muted-foreground">{action.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Upcoming Meals Timeline */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Upcoming Meals</h2>
            <Button variant="outline" size="sm" asChild data-testid="button-view-calendar">
              <Link href="/meal-planner">View Calendar</Link>
            </Button>
          </div>

          {upcomingMeals.length > 0 ? (
            <div className="flex gap-4 overflow-x-auto pb-4">
              {upcomingMeals.map((meal) => {
                const recipe = recipes.find(r => r.id === meal.recipeId);
                if (!recipe) return null;

                return (
                  <Card key={meal.id} className="min-w-[280px] hover-elevate cursor-pointer" data-testid={`card-upcoming-meal-${meal.id}`}>
                    <CardContent className="p-4">
                      <div className="flex gap-3">
                        {recipe.imageUrl && (
                          <img
                            src={recipe.imageUrl}
                            alt={recipe.name}
                            className="h-16 w-16 rounded-md object-cover"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-muted-foreground mb-1">
                            {format(new Date(meal.date), "EEE, MMM d")} • {meal.mealType}
                          </p>
                          <h3 className="font-semibold text-sm truncate">{recipe.name}</h3>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span>{recipe.prepTime + recipe.cookTime} min</span>
                            <Users className="h-3 w-3 ml-1" />
                            <span>{recipe.servings}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground mb-4">No meals planned yet</p>
                <Button asChild data-testid="button-plan-first-meal">
                  <Link href="/meal-planner">Plan Your First Meal</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
