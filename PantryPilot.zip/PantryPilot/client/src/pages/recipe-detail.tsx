import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Clock, Users, ChefHat, Calendar, ShoppingCart, Pencil } from "lucide-react";
import { Link } from "wouter";
import type { Recipe } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function RecipeDetail() {
  const [, params] = useRoute("/recipes/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [mealPlanOpen, setMealPlanOpen] = useState(false);
  const [mealDate, setMealDate] = useState("");
  const [mealType, setMealType] = useState("");

  const { data: recipe, isLoading } = useQuery<Recipe>({
    queryKey: ["/api/recipes", params?.id],
    enabled: !!params?.id,
  });

  const addToMealPlanMutation = useMutation({
    mutationFn: async () => {
      if (!recipe) return;
      return apiRequest("POST", "/api/meal-plans", {
        recipeId: recipe.id,
        date: new Date(mealDate).toISOString(),
        mealType,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      toast({
        title: "Added to meal plan",
        description: "This recipe has been scheduled successfully.",
      });
      setMealPlanOpen(false);
      setMealDate("");
      setMealType("");
    },
  });

  const addIngredientsToShoppingList = useMutation({
    mutationFn: async () => {
      if (!recipe) return;
      const promises = recipe.ingredients.map(ingredient =>
        apiRequest("POST", "/api/shopping-list", {
          name: ingredient,
          quantity: 1,
          unit: "item",
          category: "Other",
          checked: 0,
          source: "manual",
        })
      );
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
      toast({
        title: "Added to shopping list",
        description: "All ingredients have been added to your shopping list.",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-96 bg-muted rounded-lg mb-8" />
          <div className="h-8 bg-muted rounded w-1/3 mb-4" />
          <div className="h-4 bg-muted rounded w-2/3" />
        </div>
      </div>
    );
  }

  if (!recipe) {
    return (
      <div className="flex flex-col items-center justify-center p-16 text-center">
        <ChefHat className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Recipe not found</h2>
        <p className="text-muted-foreground mb-6">The recipe you're looking for doesn't exist.</p>
        <Button asChild>
          <Link href="/recipes">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Recipes
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col">
      {/* Hero Image */}
      <div className="relative h-96 overflow-hidden">
        {recipe.imageUrl ? (
          <img
            src={recipe.imageUrl}
            alt={recipe.name}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="h-full w-full bg-muted flex items-center justify-center">
            <ChefHat className="h-24 w-24 text-muted-foreground" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        <Button
          variant="outline"
          size="icon"
          className="absolute top-4 left-4 bg-background/80 backdrop-blur-sm"
          asChild
          data-testid="button-back"
        >
          <Link href="/recipes">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <Button
          variant="outline"
          size="icon"
          className="absolute top-4 right-4 bg-background/80 backdrop-blur-sm"
          asChild
          data-testid="button-edit"
        >
          <Link href={`/recipes/${recipe.id}/edit`}>
            <Pencil className="h-4 w-4" />
          </Link>
        </Button>
      </div>

      {/* Content */}
      <div className="p-8">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h1 className="text-4xl font-bold mb-3" data-testid="text-recipe-name">{recipe.name}</h1>
                {recipe.description && (
                  <p className="text-lg text-muted-foreground">{recipe.description}</p>
                )}
              </div>
            </div>

            {/* Metadata */}
            <div className="flex flex-wrap items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Prep: {recipe.prepTime} min</p>
                  <p className="text-muted-foreground">Cook: {recipe.cookTime} min</p>
                </div>
              </div>
              <Separator orientation="vertical" className="h-10" />
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">{recipe.servings} servings</p>
                </div>
              </div>
              <Separator orientation="vertical" className="h-10" />
              <div className="flex gap-2">
                <Badge variant="secondary" data-testid="badge-category">{recipe.category}</Badge>
                <Badge variant="outline" data-testid="badge-difficulty">{recipe.difficulty}</Badge>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-3 mt-6">
              <Dialog open={mealPlanOpen} onOpenChange={setMealPlanOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-to-meal-plan">
                    <Calendar className="h-4 w-4 mr-2" />
                    Add to Meal Plan
                  </Button>
                </DialogTrigger>
                <DialogContent data-testid="dialog-add-meal-plan">
                  <DialogHeader>
                    <DialogTitle>Add to Meal Plan</DialogTitle>
                    <DialogDescription>Schedule this recipe for a specific date and meal type.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="meal-date">Date</Label>
                      <Input
                        id="meal-date"
                        type="date"
                        value={mealDate}
                        onChange={(e) => setMealDate(e.target.value)}
                        data-testid="input-meal-date"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="meal-type">Meal Type</Label>
                      <Select value={mealType} onValueChange={setMealType}>
                        <SelectTrigger id="meal-type" data-testid="select-meal-type">
                          <SelectValue placeholder="Select meal type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="breakfast">Breakfast</SelectItem>
                          <SelectItem value="lunch">Lunch</SelectItem>
                          <SelectItem value="dinner">Dinner</SelectItem>
                          <SelectItem value="snack">Snack</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button
                    onClick={() => addToMealPlanMutation.mutate()}
                    disabled={!mealDate || !mealType || addToMealPlanMutation.isPending}
                    data-testid="button-confirm-add-meal-plan"
                  >
                    {addToMealPlanMutation.isPending ? "Adding..." : "Add to Plan"}
                  </Button>
                </DialogContent>
              </Dialog>
              <Button
                variant="outline"
                onClick={() => addIngredientsToShoppingList.mutate()}
                disabled={addIngredientsToShoppingList.isPending}
                data-testid="button-add-to-shopping-list"
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                {addIngredientsToShoppingList.isPending ? "Adding..." : "Add to Shopping List"}
              </Button>
            </div>
          </div>

          {/* Two Column Layout */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Ingredients */}
            <div className="lg:col-span-1">
              <Card className="lg:sticky lg:top-8">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Ingredients</h2>
                  <ul className="space-y-2" data-testid="list-ingredients">
                    {recipe.ingredients.map((ingredient, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <span className="text-primary mt-1">•</span>
                        <span>{ingredient}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Instructions */}
            <div className="lg:col-span-2">
              <h2 className="text-xl font-semibold mb-4">Instructions</h2>
              <div className="space-y-4" data-testid="list-instructions">
                {recipe.instructions.map((instruction, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold flex-shrink-0">
                      {index + 1}
                    </div>
                    <p className="flex-1 pt-1">{instruction}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
