import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, X } from "lucide-react";
import { Link } from "wouter";
import { insertRecipeSchema, type Recipe } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import breakfastImage from "@assets/generated_images/breakfast_recipe_image.png";
import lunchImage from "@assets/generated_images/lunch_bowl_recipe_image.png";
import dinnerImage from "@assets/generated_images/dinner_salmon_recipe_image.png";
import snackImage from "@assets/generated_images/snack_cookies_recipe_image.png";

const categoryImages = {
  breakfast: breakfastImage,
  lunch: lunchImage,
  dinner: dinnerImage,
  snacks: snackImage,
};

export default function RecipeForm() {
  const [, params] = useRoute("/recipes/:id/edit");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const isEdit = !!params?.id;

  const { data: recipe } = useQuery<Recipe>({
    queryKey: ["/api/recipes", params?.id],
    enabled: isEdit,
  });

  const form = useForm({
    resolver: zodResolver(insertRecipeSchema),
    defaultValues: recipe || {
      name: "",
      description: "",
      category: "lunch",
      prepTime: 15,
      cookTime: 30,
      servings: 4,
      difficulty: "medium",
      imageUrl: "",
      ingredients: [""],
      instructions: [""],
    },
  });

  const [ingredients, setIngredients] = useState<string[]>(
    recipe?.ingredients || [""]
  );
  const [instructions, setInstructions] = useState<string[]>(
    recipe?.instructions || [""]
  );

  const createMutation = useMutation({
    mutationFn: (data: any) => {
      const category = data.category.toLowerCase();
      const payload = {
        ...data,
        imageUrl: categoryImages[category as keyof typeof categoryImages] || "",
        ingredients,
        instructions,
      };
      
      if (isEdit) {
        return apiRequest("PATCH", `/api/recipes/${params?.id}`, payload);
      }
      return apiRequest("POST", "/api/recipes", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({
        title: isEdit ? "Recipe updated" : "Recipe created",
        description: isEdit ? "Your recipe has been updated successfully." : "Your recipe has been created successfully.",
      });
      setLocation("/recipes");
    },
  });

  const addIngredient = () => {
    setIngredients([...ingredients, ""]);
  };

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const updateIngredient = (index: number, value: string) => {
    const updated = [...ingredients];
    updated[index] = value;
    setIngredients(updated);
  };

  const addInstruction = () => {
    setInstructions([...instructions, ""]);
  };

  const removeInstruction = (index: number) => {
    setInstructions(instructions.filter((_, i) => i !== index));
  };

  const updateInstruction = (index: number, value: string) => {
    const updated = [...instructions];
    updated[index] = value;
    setInstructions(updated);
  };

  const onSubmit = (data: any) => {
    const filteredIngredients = ingredients.filter(i => i.trim() !== "");
    const filteredInstructions = instructions.filter(i => i.trim() !== "");
    
    if (filteredIngredients.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one ingredient.",
        variant: "destructive",
      });
      return;
    }
    
    if (filteredInstructions.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one instruction.",
        variant: "destructive",
      });
      return;
    }

    createMutation.mutate(data);
  };

  return (
    <div className="p-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" asChild data-testid="button-back">
            <Link href="/recipes">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{isEdit ? "Edit Recipe" : "Add New Recipe"}</h1>
            <p className="text-muted-foreground">Fill in the details to {isEdit ? "update" : "create"} a recipe</p>
          </div>
        </div>

        {/* Form */}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Recipe Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Grilled Salmon with Asparagus" {...field} data-testid="input-recipe-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Brief description of the recipe..."
                          {...field}
                          value={field.value || ""}
                          data-testid="input-recipe-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-category">
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="breakfast">Breakfast</SelectItem>
                            <SelectItem value="lunch">Lunch</SelectItem>
                            <SelectItem value="dinner">Dinner</SelectItem>
                            <SelectItem value="snacks">Snacks</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="difficulty"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Difficulty</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-difficulty">
                              <SelectValue placeholder="Select difficulty" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="easy">Easy</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="hard">Hard</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="prepTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Prep Time (min)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                            data-testid="input-prep-time"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="cookTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cook Time (min)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                            data-testid="input-cook-time"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="servings"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Servings</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                            data-testid="input-servings"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Ingredients</CardTitle>
                  <Button type="button" variant="outline" size="sm" onClick={addIngredient} data-testid="button-add-ingredient">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Ingredient
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {ingredients.map((ingredient, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      placeholder="e.g., 2 cups all-purpose flour"
                      value={ingredient}
                      onChange={(e) => updateIngredient(index, e.target.value)}
                      data-testid={`input-ingredient-${index}`}
                    />
                    {ingredients.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => removeIngredient(index)}
                        data-testid={`button-remove-ingredient-${index}`}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Instructions</CardTitle>
                  <Button type="button" variant="outline" size="sm" onClick={addInstruction} data-testid="button-add-instruction">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Step
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {instructions.map((instruction, index) => (
                  <div key={index} className="flex gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-sm font-semibold flex-shrink-0 mt-1">
                      {index + 1}
                    </div>
                    <Textarea
                      placeholder="Describe this step..."
                      value={instruction}
                      onChange={(e) => updateInstruction(index, e.target.value)}
                      className="resize-none"
                      rows={2}
                      data-testid={`input-instruction-${index}`}
                    />
                    {instructions.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => removeInstruction(index)}
                        className="flex-shrink-0"
                        data-testid={`button-remove-instruction-${index}`}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button
                type="submit"
                disabled={createMutation.isPending}
                data-testid="button-submit-recipe"
              >
                {createMutation.isPending ? "Saving..." : isEdit ? "Update Recipe" : "Create Recipe"}
              </Button>
              <Button type="button" variant="outline" asChild data-testid="button-cancel">
                <Link href="/recipes">Cancel</Link>
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
