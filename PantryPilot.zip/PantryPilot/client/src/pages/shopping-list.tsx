import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, ShoppingCart } from "lucide-react";
import type { ShoppingListItem } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import emptyShoppingImage from "@assets/generated_images/empty_shopping_list_illustration.png";

const categories = ["Produce", "Dairy", "Meat", "Grains", "Canned", "Frozen", "Spices", "Other"];
const units = ["cups", "tbsp", "tsp", "lbs", "oz", "items", "grams", "ml", "liters"];

export default function ShoppingList() {
  const [addItemOpen, setAddItemOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    quantity: 1,
    unit: "items",
    category: "Other",
  });
  const { toast } = useToast();

  const { data: shoppingList = [], isLoading } = useQuery<ShoppingListItem[]>({
    queryKey: ["/api/shopping-list"],
  });

  const addItemMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/shopping-list", {
        ...formData,
        checked: 0,
        source: "manual",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
      toast({
        title: "Item added",
        description: "The item has been added to your shopping list.",
      });
      setAddItemOpen(false);
      setFormData({
        name: "",
        quantity: 1,
        unit: "items",
        category: "Other",
      });
    },
  });

  const toggleItemMutation = useMutation({
    mutationFn: ({ id, checked }: { id: string; checked: number }) => {
      return apiRequest("PATCH", `/api/shopping-list/${id}`, { checked });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/shopping-list/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
      toast({
        title: "Item removed",
        description: "The item has been removed from your shopping list.",
      });
    },
  });

  const clearCompletedMutation = useMutation({
    mutationFn: async () => {
      const checkedItems = shoppingList.filter((item) => item.checked === 1);
      return Promise.all(
        checkedItems.map((item) => apiRequest("DELETE", `/api/shopping-list/${item.id}`, undefined))
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
      toast({
        title: "Completed items cleared",
        description: "All checked items have been removed from your list.",
      });
    },
  });

  const groupedItems = categories.reduce((acc, category) => {
    const items = shoppingList.filter((item) => item.category === category);
    if (items.length > 0) {
      acc[category] = items;
    }
    return acc;
  }, {} as Record<string, ShoppingListItem[]>);

  const completedCount = shoppingList.filter((item) => item.checked === 1).length;

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-1/3 mb-8" />
          <div className="h-96 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Shopping List</h1>
            <p className="text-muted-foreground">
              {shoppingList.length > 0
                ? `${completedCount} of ${shoppingList.length} items completed`
                : "Your shopping list is empty"}
            </p>
          </div>
          <Dialog open={addItemOpen} onOpenChange={setAddItemOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-item">
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent data-testid="dialog-add-item">
              <DialogHeader>
                <DialogTitle>Add Shopping List Item</DialogTitle>
                <DialogDescription>Add a new item to your shopping list.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="item-name">Item Name</Label>
                  <Input
                    id="item-name"
                    placeholder="e.g., Milk"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    data-testid="input-item-name"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                      data-testid="input-quantity"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Unit</Label>
                    <Select
                      value={formData.unit}
                      onValueChange={(value) => setFormData({ ...formData, unit: value })}
                    >
                      <SelectTrigger id="unit" data-testid="select-unit">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {units.map((unit) => (
                          <SelectItem key={unit} value={unit}>
                            {unit}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger id="category" data-testid="select-category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={() => addItemMutation.mutate()}
                disabled={!formData.name || addItemMutation.isPending}
                data-testid="button-confirm-add-item"
              >
                {addItemMutation.isPending ? "Adding..." : "Add Item"}
              </Button>
            </DialogContent>
          </Dialog>
        </div>

        {/* Shopping List */}
        {shoppingList.length > 0 ? (
          <>
            <div className="space-y-6 mb-6">
              {Object.entries(groupedItems).map(([category, items]) => (
                <Card key={category}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{category}</CardTitle>
                      <Badge variant="secondary" data-testid={`badge-count-${category.toLowerCase()}`}>
                        {items.length} item{items.length !== 1 ? "s" : ""}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {items.map((item) => (
                        <div
                          key={item.id}
                          className="flex items-center gap-3 p-3 rounded-md hover-elevate"
                          data-testid={`item-${item.id}`}
                        >
                          <Checkbox
                            checked={item.checked === 1}
                            onCheckedChange={(checked) =>
                              toggleItemMutation.mutate({
                                id: item.id,
                                checked: checked ? 1 : 0,
                              })
                            }
                            data-testid={`checkbox-${item.id}`}
                          />
                          <div className="flex-1">
                            <p
                              className={`font-medium ${
                                item.checked === 1 ? "line-through text-muted-foreground" : ""
                              }`}
                            >
                              {item.name}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {item.quantity} {item.unit}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteItemMutation.mutate(item.id)}
                            data-testid={`button-delete-${item.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {completedCount > 0 && (
              <div className="flex justify-center">
                <Button
                  variant="outline"
                  onClick={() => clearCompletedMutation.mutate()}
                  disabled={clearCompletedMutation.isPending}
                  data-testid="button-clear-completed"
                >
                  {clearCompletedMutation.isPending ? "Clearing..." : "Clear Completed Items"}
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <img src={emptyShoppingImage} alt="Empty shopping list" className="h-32 w-32 mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">Your shopping list is empty</h3>
            <p className="text-muted-foreground mb-6">
              Add items manually or schedule meals to auto-generate your list
            </p>
            <Button onClick={() => setAddItemOpen(true)} data-testid="button-add-first-item">
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Item
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
