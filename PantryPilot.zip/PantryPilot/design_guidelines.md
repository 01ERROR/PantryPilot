# PantryPilot Design Guidelines

## Design Approach

**System Selection**: Productivity-focused design inspired by **Notion** and **Linear** - clean, efficient, data-dense layouts optimized for daily use. This approach prioritizes clarity, quick scanning, and seamless workflow over visual showmanship.

**Core Principles**: 
- Information hierarchy through typography and spacing, not color
- Generous whitespace for cognitive ease
- Fast, intuitive interactions with minimal friction
- Consistent, predictable patterns across all views

---

## Typography

**Font Stack**:
- **Headings**: Inter (600/700 weights) - clean, modern sans-serif
- **Body/UI**: Inter (400/500 weights) - excellent readability at all sizes
- **Data/Numbers**: SF Mono or Roboto Mono (400 weight) - for quantities, dates, timers

**Scale**:
- Page titles: text-3xl (30px)
- Section headers: text-xl (20px)
- Card titles: text-lg (18px)
- Body text: text-base (16px)
- Supporting text: text-sm (14px)
- Labels/metadata: text-xs (12px)

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 8, 12, 16** exclusively
- Micro spacing (icons, inline elements): p-2, gap-2
- Component padding: p-4 to p-8
- Section spacing: py-12, py-16
- Page margins: px-4 (mobile), px-8 (desktop)

**Grid Structure**:
- Sidebar navigation: 256px fixed width (desktop)
- Main content: max-w-7xl with responsive padding
- Recipe cards: 3-column grid (lg:grid-cols-3 md:grid-cols-2 grid-cols-1)
- Calendar: 7-column grid for week view

---

## Component Library

### Navigation
**Top Bar**: Full-width header with logo (left), search bar (center), user profile/settings (right). Height: h-16. Sticky positioning.

**Sidebar** (Desktop only): Fixed left sidebar with primary navigation - Dashboard, Meal Planner, Recipes, Pantry, Shopping List. Each item with icon + label. Collapsible on tablet.

### Dashboard
**Hero Section**: Welcome banner with user name, current week overview stats (meals planned, pantry items expiring soon, incomplete shopping list). Height: auto, not forced viewport.

**Quick Actions Grid**: 2x2 card grid (lg:grid-cols-4 md:grid-cols-2) - "Plan This Week," "Browse Recipes," "Check Pantry," "View Shopping List." Each card with icon, title, brief description.

**Upcoming Meals Timeline**: Horizontal scrollable timeline showing next 7 days with planned meals as compact cards.

### Meal Planner Calendar
**Week View**: 7-column grid (days) with time slots. Drag-and-drop meal cards into slots. Each meal card shows thumbnail image, recipe name, prep time. Empty slots have dashed borders with "+ Add meal" prompt.

**Month View**: Calendar grid with meal indicators (small dots/icons) for high-level planning.

### Recipe Library
**Search & Filter Bar**: Sticky top bar with search input (w-full max-w-2xl), category filters (chips: Breakfast, Lunch, Dinner, Snacks), dietary tags, prep time filter.

**Recipe Cards**: Image-dominant cards with rounded corners (rounded-lg), overlay gradient for text readability. Each card: recipe image (16:9 ratio), title, prep time, servings, difficulty badge. Hover: subtle scale transform.

**Recipe Detail Page**: 
- Hero image (aspect-video, max-h-96)
- Title, description, metadata row (prep time, cook time, servings, difficulty)
- Two-column layout: Ingredients list (left, sticky), Instructions (right, numbered steps)
- Action buttons: "Add to Meal Plan," "Add to Shopping List," "Save Recipe"

### Pantry Inventory
**List View**: Table with columns: Item Name, Quantity, Unit, Category, Expiration Date, Actions. Sortable headers. Row hover highlights.

**Expiring Soon Alert**: Banner at top showing items expiring within 7 days with warning styling.

**Add Item Form**: Modal/drawer with fields: item name (autocomplete), quantity, unit (dropdown), category, purchase date, expiration date.

### Shopping List
**Categorized List**: Items grouped by category (Produce, Dairy, Meat, etc.). Checkbox for each item. Checked items get strikethrough styling. "Clear Completed" button at bottom.

**Smart Add**: Auto-populated from meal plan gaps. Manual add input at top.

### Forms & Inputs
**Text Inputs**: Border styling, focus ring, label above input. Height: h-12. Rounded: rounded-md.

**Buttons**: 
- Primary: Solid background, medium height (h-10), rounded-md, font-medium
- Secondary: Outline style
- Icon buttons: Square (w-10 h-10) with centered icon

**Dropdowns/Select**: Custom styled matching input fields. Chevron icon indicator.

**Checkboxes**: Rounded-sm, accent styling, medium size (w-5 h-5).

### Cards
**Recipe Card**: Image top, content padding p-4, rounded-lg, subtle shadow, hover elevation.

**Stat Card**: Icon (top-left), large number (center), label (bottom), minimal padding p-6.

**Meal Card** (for calendar): Compact, horizontal layout, small thumbnail (left), text (right), draggable handle icon.

---

## Images

**Hero Image**: Yes - Full-width hero banner on homepage showing organized pantry/meal prep scene. Aspect ratio: 21:9 or 16:9, max-height: 400px. Overlay gradient for text/CTA readability.

**Recipe Images**: Required for all recipe cards and detail pages. Use food photography - bright, appetizing, overhead shots preferred. Aspect ratio: 16:9 for cards, 21:9 for detail page hero.

**Empty States**: Illustrations for empty pantry, no meals planned, empty shopping list. Simple line art style, centered with supporting text.

**Category Icons**: Use Heroicons for navigation, actions, and category indicators throughout.

---

## Animations

Minimal, purposeful only:
- Card hover: `transform: scale(1.02)` with transition-transform duration-200
- Drag-and-drop: Subtle shadow increase during drag
- Modal/drawer: Slide-in from right (300ms ease-out)
- No scroll animations, parallax, or decorative motion