import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Recipes table
export const recipes = pgTable("recipes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // breakfast, lunch, dinner, snacks
  prepTime: integer("prepTime").notNull(), // in minutes
  cookTime: integer("cookTime").notNull(), // in minutes
  servings: integer("servings").notNull(),
  difficulty: text("difficulty").notNull(), // easy, medium, hard
  imageUrl: text("imageUrl"),
  ingredients: text("ingredients").array().notNull(), // Array of ingredient strings
  instructions: text("instructions").array().notNull(), // Array of instruction steps
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
});

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;

// Pantry items table
export const pantryItems = pgTable("pantryItems", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  quantity: integer("quantity").notNull(),
  unit: text("unit").notNull(), // cups, tbsp, lbs, oz, items, etc.
  category: text("category").notNull(), // produce, dairy, meat, grains, etc.
  purchaseDate: timestamp("purchaseDate", { mode: "string" }).notNull(),
  expirationDate: timestamp("expirationDate", { mode: "string" }),
});

export const insertPantryItemSchema = createInsertSchema(pantryItems).omit({
  id: true,
});

export type InsertPantryItem = z.infer<typeof insertPantryItemSchema>;
export type PantryItem = typeof pantryItems.$inferSelect;

// Meal plans table
export const mealPlans = pgTable("mealPlans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  recipeId: varchar("recipeId").notNull().references(() => recipes.id, { onDelete: "cascade" }),
  date: timestamp("date", { mode: "string" }).notNull(),
  mealType: text("mealType").notNull(), // breakfast, lunch, dinner, snack
});

export const insertMealPlanSchema = createInsertSchema(mealPlans).omit({
  id: true,
});

export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;
export type MealPlan = typeof mealPlans.$inferSelect;

// Shopping list items table
export const shoppingListItems = pgTable("shoppingListItems", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  quantity: integer("quantity").notNull(),
  unit: text("unit").notNull(),
  category: text("category").notNull(),
  checked: integer("checked").notNull().default(0), // 0 = unchecked, 1 = checked (using integer for boolean)
  source: text("source"), // "manual" or "meal-plan" or "pantry-gap"
});

export const insertShoppingListItemSchema = createInsertSchema(shoppingListItems).omit({
  id: true,
});

export type InsertShoppingListItem = z.infer<typeof insertShoppingListItemSchema>;
export type ShoppingListItem = typeof shoppingListItems.$inferSelect;
