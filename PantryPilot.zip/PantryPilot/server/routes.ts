import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertRecipeSchema,
  insertPantryItemSchema,
  insertMealPlanSchema,
  insertShoppingListItemSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Recipe Routes
  app.get("/api/recipes", async (req, res) => {
    try {
      const recipes = await storage.getRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recipes" });
    }
  });

  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const recipe = await storage.getRecipe(req.params.id);
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      res.json(recipe);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recipe" });
    }
  });

  app.post("/api/recipes", async (req, res) => {
    try {
      const validated = insertRecipeSchema.parse(req.body);
      const recipe = await storage.createRecipe(validated);
      res.status(201).json(recipe);
    } catch (error) {
      res.status(400).json({ error: "Invalid recipe data" });
    }
  });

  app.patch("/api/recipes/:id", async (req, res) => {
    try {
      const validated = insertRecipeSchema.partial().parse(req.body);
      const recipe = await storage.updateRecipe(req.params.id, validated);
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      res.json(recipe);
    } catch (error) {
      res.status(400).json({ error: "Invalid recipe data" });
    }
  });

  app.delete("/api/recipes/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteRecipe(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete recipe" });
    }
  });

  // Pantry Routes
  app.get("/api/pantry", async (req, res) => {
    try {
      const items = await storage.getPantryItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch pantry items" });
    }
  });

  app.get("/api/pantry/:id", async (req, res) => {
    try {
      const item = await storage.getPantryItem(req.params.id);
      if (!item) {
        return res.status(404).json({ error: "Pantry item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch pantry item" });
    }
  });

  app.post("/api/pantry", async (req, res) => {
    try {
      const validated = insertPantryItemSchema.parse(req.body);
      const item = await storage.createPantryItem(validated);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ error: "Invalid pantry item data" });
    }
  });

  app.delete("/api/pantry/:id", async (req, res) => {
    try {
      const deleted = await storage.deletePantryItem(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Pantry item not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete pantry item" });
    }
  });

  // Meal Plan Routes
  app.get("/api/meal-plans", async (req, res) => {
    try {
      const plans = await storage.getMealPlans();
      res.json(plans);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch meal plans" });
    }
  });

  app.get("/api/meal-plans/:id", async (req, res) => {
    try {
      const plan = await storage.getMealPlan(req.params.id);
      if (!plan) {
        return res.status(404).json({ error: "Meal plan not found" });
      }
      res.json(plan);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch meal plan" });
    }
  });

  app.post("/api/meal-plans", async (req, res) => {
    try {
      const validated = insertMealPlanSchema.parse(req.body);
      const plan = await storage.createMealPlan(validated);
      res.status(201).json(plan);
    } catch (error) {
      res.status(400).json({ error: "Invalid meal plan data" });
    }
  });

  app.delete("/api/meal-plans/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteMealPlan(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Meal plan not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete meal plan" });
    }
  });

  // Shopping List Routes
  app.get("/api/shopping-list", async (req, res) => {
    try {
      const items = await storage.getShoppingListItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch shopping list" });
    }
  });

  app.get("/api/shopping-list/:id", async (req, res) => {
    try {
      const item = await storage.getShoppingListItem(req.params.id);
      if (!item) {
        return res.status(404).json({ error: "Shopping list item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch shopping list item" });
    }
  });

  app.post("/api/shopping-list", async (req, res) => {
    try {
      const validated = insertShoppingListItemSchema.parse(req.body);
      const item = await storage.createShoppingListItem(validated);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ error: "Invalid shopping list item data" });
    }
  });

  app.patch("/api/shopping-list/:id", async (req, res) => {
    try {
      const validated = insertShoppingListItemSchema.partial().parse(req.body);
      const item = await storage.updateShoppingListItem(req.params.id, validated);
      if (!item) {
        return res.status(404).json({ error: "Shopping list item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(400).json({ error: "Invalid shopping list item data" });
    }
  });

  app.delete("/api/shopping-list/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteShoppingListItem(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Shopping list item not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete shopping list item" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
