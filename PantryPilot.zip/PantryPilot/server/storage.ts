import {
  type Recipe,
  type InsertRecipe,
  type PantryItem,
  type InsertPantryItem,
  type MealPlan,
  type InsertMealPlan,
  type ShoppingListItem,
  type InsertShoppingListItem,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Recipes
  getRecipes(): Promise<Recipe[]>;
  getRecipe(id: string): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: string, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined>;
  deleteRecipe(id: string): Promise<boolean>;

  // Pantry Items
  getPantryItems(): Promise<PantryItem[]>;
  getPantryItem(id: string): Promise<PantryItem | undefined>;
  createPantryItem(item: InsertPantryItem): Promise<PantryItem>;
  deletePantryItem(id: string): Promise<boolean>;

  // Meal Plans
  getMealPlans(): Promise<MealPlan[]>;
  getMealPlan(id: string): Promise<MealPlan | undefined>;
  createMealPlan(plan: InsertMealPlan): Promise<MealPlan>;
  deleteMealPlan(id: string): Promise<boolean>;

  // Shopping List
  getShoppingListItems(): Promise<ShoppingListItem[]>;
  getShoppingListItem(id: string): Promise<ShoppingListItem | undefined>;
  createShoppingListItem(item: InsertShoppingListItem): Promise<ShoppingListItem>;
  updateShoppingListItem(id: string, item: Partial<InsertShoppingListItem>): Promise<ShoppingListItem | undefined>;
  deleteShoppingListItem(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private recipes: Map<string, Recipe>;
  private pantryItems: Map<string, PantryItem>;
  private mealPlans: Map<string, MealPlan>;
  private shoppingListItems: Map<string, ShoppingListItem>;

  constructor() {
    this.recipes = new Map();
    this.pantryItems = new Map();
    this.mealPlans = new Map();
    this.shoppingListItems = new Map();
  }

  // Recipes
  async getRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }

  async getRecipe(id: string): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const id = randomUUID();
    const recipe: Recipe = {
      ...insertRecipe,
      id,
      description: insertRecipe.description ?? null,
      imageUrl: insertRecipe.imageUrl ?? null,
    };
    this.recipes.set(id, recipe);
    return recipe;
  }

  async updateRecipe(id: string, updates: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const recipe = this.recipes.get(id);
    if (!recipe) return undefined;
    
    const updatedRecipe = { ...recipe, ...updates };
    this.recipes.set(id, updatedRecipe);
    return updatedRecipe;
  }

  async deleteRecipe(id: string): Promise<boolean> {
    return this.recipes.delete(id);
  }

  // Pantry Items
  async getPantryItems(): Promise<PantryItem[]> {
    return Array.from(this.pantryItems.values());
  }

  async getPantryItem(id: string): Promise<PantryItem | undefined> {
    return this.pantryItems.get(id);
  }

  async createPantryItem(insertItem: InsertPantryItem): Promise<PantryItem> {
    const id = randomUUID();
    const item: PantryItem = {
      ...insertItem,
      id,
      expirationDate: insertItem.expirationDate ?? null,
    };
    this.pantryItems.set(id, item);
    return item;
  }

  async deletePantryItem(id: string): Promise<boolean> {
    return this.pantryItems.delete(id);
  }

  // Meal Plans
  async getMealPlans(): Promise<MealPlan[]> {
    return Array.from(this.mealPlans.values());
  }

  async getMealPlan(id: string): Promise<MealPlan | undefined> {
    return this.mealPlans.get(id);
  }

  async createMealPlan(insertPlan: InsertMealPlan): Promise<MealPlan> {
    const id = randomUUID();
    const plan: MealPlan = { ...insertPlan, id };
    this.mealPlans.set(id, plan);
    return plan;
  }

  async deleteMealPlan(id: string): Promise<boolean> {
    return this.mealPlans.delete(id);
  }

  // Shopping List
  async getShoppingListItems(): Promise<ShoppingListItem[]> {
    return Array.from(this.shoppingListItems.values());
  }

  async getShoppingListItem(id: string): Promise<ShoppingListItem | undefined> {
    return this.shoppingListItems.get(id);
  }

  async createShoppingListItem(insertItem: InsertShoppingListItem): Promise<ShoppingListItem> {
    const id = randomUUID();
    const item: ShoppingListItem = {
      ...insertItem,
      id,
      checked: insertItem.checked ?? 0,
      source: insertItem.source ?? null,
    };
    this.shoppingListItems.set(id, item);
    return item;
  }

  async updateShoppingListItem(id: string, updates: Partial<InsertShoppingListItem>): Promise<ShoppingListItem | undefined> {
    const item = this.shoppingListItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...updates };
    this.shoppingListItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteShoppingListItem(id: string): Promise<boolean> {
    return this.shoppingListItems.delete(id);
  }
}

export const storage = new MemStorage();
