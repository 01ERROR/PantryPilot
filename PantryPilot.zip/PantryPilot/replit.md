# PantryPilot

A comprehensive food planning web application for meal planning, recipe management, pantry tracking, and smart shopping list generation.

## Overview

PantryPilot is a full-stack JavaScript application built with React, Express, and in-memory storage. It helps users plan meals, manage recipes, track pantry inventory with expiration dates, and automatically generate shopping lists.

## Recent Changes

### November 24, 2025
- Initial implementation of PantryPilot MVP
- Designed comprehensive data schema for recipes, pantry items, meal plans, and shopping lists
- Built complete frontend UI with 7 pages: Dashboard, Recipe Library, Recipe Detail, Recipe Form, Meal Planner, Pantry, and Shopping List
- Implemented theme provider for dark mode support
- Generated custom images for recipe categories and empty states
- Configured Inter font family and fresh green color scheme

## Project Architecture

### Frontend Stack
- **Framework**: React with TypeScript
- **Routing**: Wouter
- **State Management**: TanStack Query (React Query v5)
- **UI Components**: Shadcn UI with Radix primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Forms**: React Hook Form with Zod validation

### Backend Stack
- **Server**: Express.js
- **Storage**: In-memory storage (MemStorage)
- **Validation**: Zod schemas
- **Type Safety**: Shared TypeScript types

### Data Models
1. **Recipes**: Name, description, category, prep/cook time, servings, difficulty, ingredients, instructions
2. **Pantry Items**: Name, quantity, unit, category, purchase date, expiration date
3. **Meal Plans**: Recipe reference, date, meal type (breakfast/lunch/dinner/snack)
4. **Shopping List Items**: Name, quantity, unit, category, checked status, source

## Key Features

### MVP Features
- ✅ Weekly meal planner calendar with date-based scheduling
- ✅ Recipe library with search and category/difficulty filtering
- ✅ Recipe detail pages with ingredients and instructions
- ✅ Pantry inventory tracking with expiration date monitoring
- ✅ Shopping list with categorized items and checkbox completion
- ✅ Dark mode support
- ✅ Responsive design following productivity-focused design guidelines

### Future Enhancements
- Nutritional information tracking
- Recipe scaling for different serving sizes
- Recipe sharing and import from websites
- Expiration date alerts and waste tracking
- Meal prep batch cooking suggestions

## User Preferences
- Design approach: Clean, productivity-focused, inspired by Notion and Linear
- Color scheme: Fresh green primary color (hsl(142, 76%, 36%))
- Typography: Inter font family
- Component library: Shadcn UI with consistent spacing and elevation system

## File Structure
```
client/src/
  components/
    ui/ - Shadcn UI components
    app-sidebar.tsx - Navigation sidebar
    theme-provider.tsx - Dark mode theme management
    theme-toggle.tsx - Theme toggle button
  pages/
    dashboard.tsx - Home page with stats and upcoming meals
    recipes.tsx - Recipe library with filters
    recipe-detail.tsx - Individual recipe view
    recipe-form.tsx - Add/edit recipe form
    meal-planner.tsx - Weekly calendar view
    pantry.tsx - Pantry inventory management
    shopping-list.tsx - Shopping list with categories
  App.tsx - Main app with routing and sidebar layout
  
server/
  storage.ts - In-memory storage implementation
  routes.ts - API endpoints
  
shared/
  schema.ts - Shared TypeScript types and Zod schemas
```

## API Endpoints (To be implemented)
- GET /api/recipes - List all recipes
- GET /api/recipes/:id - Get recipe by ID
- POST /api/recipes - Create new recipe
- PATCH /api/recipes/:id - Update recipe
- DELETE /api/recipes/:id - Delete recipe
- GET /api/meal-plans - List all meal plans
- POST /api/meal-plans - Create meal plan
- DELETE /api/meal-plans/:id - Delete meal plan
- GET /api/pantry - List all pantry items
- POST /api/pantry - Add pantry item
- DELETE /api/pantry/:id - Delete pantry item
- GET /api/shopping-list - List all shopping list items
- POST /api/shopping-list - Add shopping list item
- PATCH /api/shopping-list/:id - Update shopping list item (toggle checked)
- DELETE /api/shopping-list/:id - Delete shopping list item
