const mongoose = require('mongoose');

const PantrySchema = new mongoose.Schema({
  name: { type: String, required: true },
  quantity: { type: Number, default: 1 },
  expiry: { type: Date },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Pantry', PantrySchema);
