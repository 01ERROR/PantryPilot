// PantryPilot frontend (vanilla JS)
const API_BASE = '/api/pantry';

document.getElementById('open-app').addEventListener('click', () => {
  document.querySelector('.hero').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  navigate('dashboard');
  loadPantry();
});

// navigation
document.querySelectorAll('.navbtn').forEach(btn => {
  btn.addEventListener('click', () => {
    const v = btn.dataset.view;
    navigate(v);
    if (v === 'pantry') loadPantry();
  });
});

function navigate(view) {
  ['dashboard','pantry','planner','shopping','analytics'].forEach(id=>{
    const el = document.getElementById(id);
    if (id === view) el.style.display = 'block'; else el.style.display = 'none';
  });
  if (view === 'dashboard') renderDashboard();
  if (view === 'planner') renderPlanner();
  if (view === 'shopping') renderShopping();
  if (view === 'analytics') renderAnalytics();
}

async function loadPantry() {
  try {
    const res = await fetch(API_BASE);
    const items = await res.json();
    const el = document.getElementById('pantry');
    el.innerHTML = `
      <h2>Pantry</h2>
      <div id="pantry-list"></div>
      <form id="add-form">
        <input name="name" placeholder="Item name" required />
        <input name="quantity" type="number" value="1" min="1" />
        <input name="expiry" type="date" />
        <button type="submit">Add</button>
      </form>
    `;
    const list = document.getElementById('pantry-list');
    if (!items || items.length === 0) list.innerHTML = '<p class="muted">No items yet.</p>';
    else list.innerHTML = items.map(i=>`<div data-id="${i._id}">${i.name} • qty: ${i.quantity} ${i.expiry? '• exp: '+new Date(i.expiry).toLocaleDateString():''} <button class="delete">Delete</button></div>`).join('');

    document.getElementById('add-form').onsubmit = async (e) =>{
      e.preventDefault();
      const form = e.target;
      const data = { name: form.name.value, quantity: Number(form.quantity.value), expiry: form.expiry.value || null };
      await fetch(API_BASE, { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
      loadPantry();
      form.reset();
    };

    document.querySelectorAll('.delete').forEach(btn=>{
      btn.onclick = async () => {
        const id = btn.parentElement.dataset.id;
        await fetch(`${API_BASE}/${id}`, { method: 'DELETE' });
        loadPantry();
      };
    });
  } catch (err) {
    console.error('Error loading pantry', err);
  }
}

function renderDashboard(){
  const el = document.getElementById('dashboard');
  el.innerHTML = '<h2>Dashboard</h2><p class="muted">Loading summary...</p>';
  // quick summary using API
  fetch(API_BASE).then(r=>r.json()).then(items=>{
    const expiring = items.filter(i=> i.expiry && (new Date(i.expiry) - Date.now()) < 3*24*60*60*1000);
    el.innerHTML = `
      <h2>Dashboard</h2>
      <div class="card">Pantry items: ${items.length}</div>
      <div class="card">Expiring soon: ${expiring.length}</div>
      <div class="card">Estimated money saved: ₹0</div>
    `;
  }).catch(()=>{ el.innerHTML = '<h2>Dashboard</h2><p class="muted">Unable to load data</p>';});
}

function renderPlanner(){
  const el = document.getElementById('planner');
  el.innerHTML = '<h2>Meal Planner</h2><p class="muted">Basic planner UI — connect recipe engine for suggestions.</p><div class="card"><div>Breakfast: —</div><div>Lunch: —</div><div>Dinner: —</div></div>';
}

function renderShopping(){
  const el = document.getElementById('shopping');
  el.innerHTML = '<h2>Shopping List</h2><ul><li>Tomatoes</li><li>Rice</li></ul>';
}

function renderAnalytics(){
  const el = document.getElementById('analytics');
  el.innerHTML = '<h2>Analytics</h2><p class="muted">Add charts to visualize waste, usage, and savings.</p>';
}
