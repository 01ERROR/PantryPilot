PantryPilot - Full working starter

Quick start:

1. Install Node.js (v18+ recommended) and npm.
2. Extract this ZIP.
3. In the project folder, run:
   npm install
4. Create a .env file (see .env.example) and set MONGODB_URI.
5. Start the server:
   npm start
6. Open http://localhost:5000 in your browser.

The frontend is served from /public and calls the backend API at /api/pantry.

If you want to deploy:
- Upload the project to Cyclic.sh (upload ZIP) or Render/Heroku.
- For Netlify frontend, upload public/ and set API_BASE to your backend URL.

